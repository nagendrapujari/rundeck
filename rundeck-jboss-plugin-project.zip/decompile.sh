#!/bin/bash
# Script to decompile extracted class files into Java sources using CFR
# Usage: run in environment with bash, wget, java installed
set -e
CFR_URL="https://github.com/leibnitz27/cfr/releases/latest/download/cfr.jar"
CFR_JAR="cfr.jar"
if [ ! -f "$CFR_JAR" ]; then
  echo "Downloading CFR decompiler..."
  wget -O "$CFR_JAR" "$CFR_URL"
fi
EXTRACTED_DIR="../extracted_classes"  # adjust path to where you placed .class files
OUT_DIR="src/main/java"
mkdir -p "$OUT_DIR"
# Find all class files and decompile each preserving package structure
find "$EXTRACTED_DIR" -name '*.class' | while read cls; do
  # compute package path
  rel=$(realpath --relative-to="$EXTRACTED_DIR" "$cls")
  outdir=$(dirname "$OUT_DIR/$rel")
  mkdir -p "$outdir"
  java -jar "$CFR_JAR" "$cls" --outputdir "$outdir"
done
echo "Decompilation finished. Check src/main/java for .java files."
