Instructions to decompile, port, and build the plugin for Rundeck 5.11
Steps:
1) Download and unzip the attached 'com_cacib_classes_bundle.zip' somewhere, e.g. alongside this project.
   unzip /path/to/com_cacib_classes_bundle.zip -d extracted_classes
2) Run the decompiler script to convert .class files to .java (script uses CFR decompiler):
   cd rundeck-jboss-plugin-project
   ./decompile.sh
   # ensure the DECOMPILER script points to the extracted_classes folder
3) Review the generated Java files in src/main/java. Fix imports and replace old Rundeck API usages:
   - update package imports from any old com.dtolabs.* to org.rundeck.*
   - add @Plugin annotations where appropriate (see Rundeck 5 plugin docs)
   - create/adjust META-INF/plugin.yaml for providers (already present)
4) Build with Maven (JDK 11+):
   mvn -U clean package
   # Ensure rundeck-core is provided scope; the produced jar will be in target/
5) Deploy the built JAR to Rundeck's libext/plugins directory and restart Rundeck.
   cp target/rundeck-jboss-deployment-plugins-1.0.4-5x.jar /var/lib/rundeck/libext/
   systemctl restart rundeckd
